<?php
if (!defined('PAYMENT')) {
    http_response_code(404);
    die();
}

$paymentkey = $_REQUEST['payment_key'];
if (empty($paymentkey)) {
    $up_response = file_get_contents('php://input');
    $up_response_decode = json_decode($up_response, true);
    $paymentkey = $up_response_decode['payment_key'];
}

if (empty($paymentkey)) {
    errorExit("Direct access is not allowed.");
}

$apiKey =  trim($methodExtras['api_key']);
$apiUrl = 'https://request.bohudur.one/execute/';

$payment_data = [
    'paymentkey' => $paymentkey
];

$curl = curl_init();
curl_setopt_array($curl, [
    CURLOPT_URL => $apiUrl,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "POST",
    CURLOPT_POSTFIELDS => json_encode($payment_data),
    CURLOPT_HTTPHEADER => [
        "AH-BOHUDUR-API-KEY: " . $apiKey,
        "accept: application/json",
        "content-type: application/json"
    ],
]);

$response = curl_exec($curl);
$err = curl_error($curl);
curl_close($curl);

if ($err) {
    errorExit("cURL Error #:" . $err);
}

if (empty($response)) {
    errorExit("Invalid Response From Payment API.");
}

$data = json_decode($response, true);

if (!isset($data['Status']) && !isset($data['Metadata']['order_id'])) {
    errorExit("Invalid Response From Payment API.");
}

if (isset($data['Status']) && $data['Status'] == 'EXECUTED') {
    $metadata = json_decode($data['Metadata'], true);
    $orderId = $metadata['order_id'];
    $userId = $metadata['client_id'];
    $paymentDetails = $conn->prepare("SELECT * FROM payments WHERE payment_extra=:orderId");
    $paymentDetails->execute([
        "orderId" => $orderId
    ]);
    
    $user = $conn->prepare("SELECT * FROM clients WHERE client_id=:id");
    $user->execute(array("id"=>$userId ));
    $user = $user->fetch(PDO::FETCH_ASSOC);
    
    if ($paymentDetails->rowCount()) {
        $paymentDetails = $paymentDetails->fetch(PDO::FETCH_ASSOC);
        if (
            !countRow([
                'table' => 'payments',
                'where' => [
                    'client_id' => $user['client_id'],
                    'payment_method' => $methodId,
                    'payment_status' => 3,
                    'payment_delivery' => 2,
                    'payment_extra' => $orderId
                ]
            ])
        ) {
            $paidAmount = floatval($paymentDetails["payment_amount"]);
            if ($paymentFee > 0) {
                $fee = ($paidAmount * ($paymentFee / 100));
                $paidAmount -= $fee;
            }
            if ($paymentBonusStartAmount != 0 && $paidAmount > $paymentBonusStartAmount) {
                $bonus = $paidAmount * ($paymentBonus / 100);
                $paidAmount += $bonus;
            }

            $update = $conn->prepare('UPDATE payments SET 
                    client_balance=:balance,
                    payment_status=:status, 
                    payment_delivery=:delivery WHERE payment_id=:id');
            $update->execute([
                'balance' => $user["balance"],
                'status' => 3,
                'delivery' => 2,
                'id' => $paymentDetails['payment_id']
            ]);

            $balance = $conn->prepare('UPDATE clients SET balance=:balance WHERE client_id=:id');
            $balance->execute([
                "balance" => $user["balance"] + $paidAmount,
                "id" => $user["client_id"]
            ]);
            header("Location: " . site_url("addfunds"));
            exit();
        } else {
            header("Location: " . site_url("addfunds"));
            exit();
        }
    } else {
        errorExit("Order ID not found.");
    }
}

header("Location: " . site_url("addfunds"));
exit();

http_response_code(405);
die();