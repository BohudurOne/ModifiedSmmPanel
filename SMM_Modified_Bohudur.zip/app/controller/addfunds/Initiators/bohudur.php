<?php
if (!defined('ADDFUNDS')) {
    http_response_code(404);
    die();
}

$apiKey = $methodExtras["api_key"];
$exchangeRate = $methodExtras["exchange_rate"];
$payeeName = $user["name"] ?: "User";
$payeeEmail = $user["email"] ?: "test@test.com";
$paymentURL = site_url("payment/" . $methodCallback);
$orderId = md5(RAND_STRING(5) . time());

$insert = $conn->prepare(
    "INSERT INTO payments SET
client_id=:client_id,
payment_amount=:amount,
payment_method=:method,
payment_mode=:mode,
payment_create_date=:date,
payment_ip=:ip,
payment_extra=:extra"
);

$insert->execute([
    "client_id" => $user["client_id"],
    "amount" => $paymentAmount,
    "method" => $methodId,
    "mode" => "Automatic",
    "date" => date("Y.m.d H:i:s"),
    "ip" => GetIP(),
    "extra" => $orderId
]);

$currency_rate = 0;
if($exchangeRate > 0){
    $currency_rate = $exchangeRate;
}

$requestData = [
    'fullname'      => $payeeName,
    'email'         => $payeeEmail,
    'amount'        => $paymentAmount,
    'currency'      => 'USD',
    'currency_value' => $currency_rate,
    'metadata'      => [
        'order_id'  => $orderId,
        'client_id' => $user["client_id"]
    ],
    'redirect_url'  => $paymentURL,
    'return_type'   => 'GET',
    'cancelled_url' => site_url("")
];

$postUrl = 'https://request.bohudur.one/create/';

$curl = curl_init();
curl_setopt_array($curl, [
    CURLOPT_URL => $postUrl,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_CUSTOMREQUEST => "POST",
    CURLOPT_POSTFIELDS => json_encode($requestData),
    CURLOPT_HTTPHEADER => [
        "AH-BOHUDUR-API-KEY: " . $apiKey,
        "accept: application/json",
        "content-type: application/json"
    ],
]);

$upresponse = curl_exec($curl);
$err = curl_error($curl);
curl_close($curl);
if ($err) {
    errorExit("cURL Error #:" . $err);
} else {
    $result = json_decode($upresponse, true);
    if (isset($result['status']) && isset($result['payment_url'])) {
        $paymentUrl = $result['payment_url'];
        $redirectForm .= '<form method="GET" action=" ' . $paymentUrl . '" name="bohudurCheckoutForm">';
        $redirectForm .= '</form>
        <script type="text/javascript">
        document.bohudurCheckoutForm.submit();
        </script>';
    } else {
        errorExit($result['message']);
    }
}

$response["success"] = true;
$response["message"] = "Your payment has been initiated and you will now be redirected to the payment gateway.";
$response["content"] = $redirectForm;